public class Product {

    String productName;
    int barCode;
    double price;
    final double tax = 20;

    public Product (String productName, int barCode, double price){
        this.productName = productName;
        this.barCode = barCode;
        this.price = price;

    }

    public double getPrice(){
        double priceWithTax = price + (price * tax)/100;
        return priceWithTax;
    }

    public void showInfo(){
        System.out.println(productName);
        System.out.println(barCode);
        System.out.println(price);
        System.out.println(tax);
    }


}
