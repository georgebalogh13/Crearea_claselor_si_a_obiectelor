public class Chocolate extends Product{

    double weight;

    public Chocolate(String productName, int barCode, double price, double weight){
        super(productName, barCode, price);
        this.weight = weight;
    }

    public void showInfo(){
        super.showInfo();
        System.out.println(weight);
    }

}
