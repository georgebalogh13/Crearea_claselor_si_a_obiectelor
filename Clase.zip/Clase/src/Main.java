public class Main {

    public static void main(String[] args) {

        Product product = new Product("corn", 123456789, 5.00);
        Wine wine = new Wine("Cotnari", 1234, 20, 1.00);
        Chocolate chocolate = new Chocolate("Milka", 123, 10, 0.5);

        System.out.println(product.getPrice());
        System.out.println(wine.getPrice());
        System.out.println(chocolate.getPrice());

        System.out.println();
        product.showInfo();
        System.out.println();
        wine.showInfo();
        System.out.println();
        chocolate.showInfo();
    }

}
