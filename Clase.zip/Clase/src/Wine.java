public class Wine extends Product{

    double volume;

    public Wine(String productName, int barCode, double price, double volume){
        super(productName, barCode, price);
        this.volume = volume;
    }


    @Override public double getPrice() {
        double basePrice = super.getPrice();
        return basePrice + (basePrice * 10)/100;
    }

    public void showInfo(){
        super.showInfo();
        System.out.println(volume);
    }

}
